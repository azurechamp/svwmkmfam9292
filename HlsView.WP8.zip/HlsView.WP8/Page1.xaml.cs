﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Tasks;
using GoogleAds;
using System.Diagnostics;
using System.Windows.Threading;

namespace HlsView
{
    public partial class Page1 : PhoneApplicationPage
    {
        public Page1()
        {
            InitializeComponent();
            DispatcherTimer newTimer = new DispatcherTimer();
            newTimer.Interval = TimeSpan.FromSeconds(90);
            newTimer.Tick += OnTimerTickLoL;
            // starting the timer for loading Ad
            newTimer.Start();
        }

        private void OnTimerTickLoL(object sender, EventArgs e)
        {
            try
            {
                interstitialAd = new InterstitialAd("ca-app-pub-6412899587206454/6982893721");
                // NOTE: You can edit the event handler to do something custom here. Once the
                // interstitial is received it can be shown whenever you want.
                interstitialAd.ReceivedAd += OnAdReceived;
                interstitialAd.FailedToReceiveAd += OnFailedToReceiveAd;
                interstitialAd.DismissingOverlay += OnDismissingOverlay;
                AdRequest adRequest = new AdRequest();
                adRequest.ForceTesting = false;
                interstitialAd.LoadAd(adRequest);
            }
            catch (Exception exc)
            {
                //Sometimes you need to catch Exceptions :p lol
            }
        }

        public static void OnAdReceived(object sender, AdEventArgs e)
        {
            Debug.WriteLine("Received interstitial successfully. Click 'Show Interstitial'.");

            interstitialAd.ShowAd();
        }

        public static void OnDismissingOverlay(object sender, AdEventArgs e)
        {
            Debug.WriteLine("Dismissing interstitial.");
        }

        public static void OnFailedToReceiveAd(object sender, AdErrorEventArgs errorCode)
        {
            Debug.WriteLine("Failed to receive interstitial with error " + errorCode.ErrorCode);
        }

        private void FantacyTileButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            WebBrowserTask webBrowserTask = new WebBrowserTask();
            webBrowserTask.URL = "http://www.mtv.co.uk/music/playlists/mtv-hits-playlist";
            webBrowserTask.Show();
        }

        private void ScheduleTilePressed(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            WebBrowserTask webBrowserTask = new WebBrowserTask();
            webBrowserTask.URL = "http://www.mtv.co.uk/music/playlists/mtv-hits-playlist";
            webBrowserTask.Show();
        }

        private void about_iconbar_clicked(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/AboutPage.xaml", UriKind.Relative));
        }

        private void review_iconbar_clicked(object sender, EventArgs e)
        {
            MarketplaceReviewTask marketplacereviewtask = new MarketplaceReviewTask();
            marketplacereviewtask.Show();
        }

        private void otherapplication_iconbar_clicked(object sender, EventArgs e)
        {
            MarketplaceSearchTask marketplacesearchtask = new MarketplaceSearchTask();
            marketplacesearchtask.SearchTerms = "Procesium";
            marketplacesearchtask.Show();
        }

        public static InterstitialAd interstitialAd { get; set; }
    }
}